import { usersMongoRepo } from "./repositories/users.mongo.repo.js";

export const userRepo = usersMongoRepo;