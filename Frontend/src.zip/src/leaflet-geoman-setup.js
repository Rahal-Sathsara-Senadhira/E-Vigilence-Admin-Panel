// src/leaflet-geoman-setup.js
import * as L from "leaflet";
if (typeof window !== "undefined") window.L = L;
import "@geoman-io/leaflet-geoman-free";
import "@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css";
