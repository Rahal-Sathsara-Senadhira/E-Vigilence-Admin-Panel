import React from "react";
import { listRegionalStations, createRegionalStation } from "../../services/regionalStationsApi";

export default function RegionalStations() {
  const [stations, setStations] = React.useState([]);
  const [name, setName] = React.useState("");
  const [region, setRegion] = React.useState("");
  const [lat, setLat] = React.useState("");
  const [lng, setLng] = React.useState("");

  async function load() {
    const res = await listRegionalStations();
    setStations(res.data);
  }

  async function onSubmit(e) {
    e.preventDefault();
    await createRegionalStation({
      name,
      region,
      latitude: Number(lat),
      longitude: Number(lng),
    });
    setName("");
    setRegion("");
    setLat("");
    setLng("");
    load();
  }

  React.useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-slate-100">Regional Stations</h2>

      <form onSubmit={onSubmit} className="grid grid-cols-4 gap-3">
        <input placeholder="Station name" value={name}
          onChange={(e) => setName(e.target.value)}
          className="col-span-2 rounded-xl border bg-slate-900 p-2 text-slate-100" />

        <input placeholder="Region" value={region}
          onChange={(e) => setRegion(e.target.value)}
          className="rounded-xl border bg-slate-900 p-2 text-slate-100" />

        <input placeholder="Lat" value={lat}
          onChange={(e) => setLat(e.target.value)}
          className="rounded-xl border bg-slate-900 p-2 text-slate-100" />

        <input placeholder="Lng" value={lng}
          onChange={(e) => setLng(e.target.value)}
          className="rounded-xl border bg-slate-900 p-2 text-slate-100" />

        <button className="col-span-4 rounded-xl bg-cyan-600/20 p-2 text-cyan-200">
          Add Station
        </button>
      </form>

      <div className="rounded-2xl border bg-slate-900/40 p-4">
        {stations.map((s) => (
          <div key={s.id} className="border-b border-slate-800 py-2">
            <p className="text-slate-100 font-medium">{s.name}</p>
            <p className="text-xs text-slate-400">
              {s.region} | {s.latitude}, {s.longitude}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
